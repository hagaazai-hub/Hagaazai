// Allied Shopping POS - Main JS

function openSidebar() {
    document.getElementById('sidebar').classList.add('open');
    document.getElementById('sidebarOverlay').classList.add('active');
}

function closeSidebar() {
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('sidebarOverlay').classList.remove('active');
}

function openModal(id) {
    var el = document.getElementById(id);
    if (el) el.classList.add('active');
}

function closeModal(id) {
    var el = document.getElementById(id);
    if (el) el.classList.remove('active');
}

// Close modal on overlay click
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal-overlay')) {
        e.target.classList.remove('active');
    }
});

// Flash messages auto dismiss
document.addEventListener('DOMContentLoaded', function() {
    var alerts = document.querySelectorAll('.alert');
    alerts.forEach(function(a) {
        setTimeout(function() {
            a.style.transition = 'opacity 0.5s';
            a.style.opacity = '0';
            setTimeout(function() { a.remove(); }, 500);
        }, 4000);
    });
});

// Confirm delete helper
function confirmDelete(form) {
    if (confirm('Yakin hapus data ini?')) {
        form.submit();
    }
}

// Format currency
function formatRupiah(n) {
    return 'Rp ' + parseInt(n).toLocaleString('id-ID');
}

// Print receipt
function printReceipt(el) {
    var content = document.getElementById(el).innerHTML;
    var w = window.open('', '_blank', 'width=420,height=600');
    w.document.write('<html><head><title>Struk</title>');
    w.document.write('<link rel="stylesheet" href="' + window.BASE_URL + '/css/style.css">');
    w.document.write('</head><body style="background:#fff;padding:20px">');
    w.document.write(content);
    w.document.write('</body></html>');
    w.document.close();
    setTimeout(function() { w.print(); }, 600);
}

// Download receipt as PDF using browser print
function downloadReceiptPDF(trxId) {
    var url = window.BASE_URL + '/pages/cashier/receipt.php?id=' + trxId + '&print=1';
    var w = window.open(url, '_blank', 'width=500,height=700');
    w.onload = function() {
        setTimeout(function() { w.print(); }, 800);
    };
}
