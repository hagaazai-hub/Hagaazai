<?php
require_once '../../config.php';
requireLogin();
require_once '../../includes/layout.php';

$db = getDB();
$base = BASE_URL;

$id = (int)($_GET['id'] ?? 0);
if (!$id) {
    header('Location: ' . $base . '/pages/admin/cashiers.php');
    exit;
}

$res = mysqli_query($db, "SELECT k.*, COUNT(t.id) as trx_count, COALESCE(SUM(t.grand_total),0) as total_sales FROM kasir k LEFT JOIN transaksi t ON k.id=t.kasir_id WHERE k.id=$id GROUP BY k.id");
$kasir = mysqli_fetch_assoc($res);

if (!$kasir) {
    header('Location: ' . $base . '/pages/admin/cashiers.php');
    exit;
}

// Recent transactions
$recentTrx = mysqli_query($db, "SELECT * FROM transaksi WHERE kasir_id=$id ORDER BY created_at DESC LIMIT 10");

pageStart('Profil Kasir', 'cashiers');
?>

<div class="flex-between mb-6">
    <h2 style="font-family:var(--font-display);font-size:24px;font-weight:500">
        <span class="ornament"></span>Profil Kasir
    </h2>
    <a href="<?= $base ?>/pages/admin/cashiers.php" class="btn btn-ghost btn-sm">
        <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
        Kembali
    </a>
</div>

<div style="display:grid;grid-template-columns:300px 1fr;gap:20px;align-items:start">

    <!-- Profile Card -->
    <div class="card" style="text-align:center;padding:28px 20px">
        <div style="width:72px;height:72px;border-radius:50%;background:var(--gold-dim);border:2px solid var(--gold);display:flex;align-items:center;justify-content:center;font-family:var(--font-display);font-size:28px;color:var(--gold);margin:0 auto 16px">
            <?= strtoupper(substr($kasir['username'],0,1)) ?>
        </div>
        <div style="font-size:20px;font-weight:600;font-family:var(--font-display);color:var(--text);margin-bottom:4px">
            <?= htmlspecialchars($kasir['username']) ?>
            <?php if ($kasir['id'] == $_SESSION['cashier_id']): ?>
            <span class="badge badge-gold" style="font-size:10px;vertical-align:middle">Saya</span>
            <?php endif; ?>
        </div>
        <div style="color:var(--text3);font-size:13px;margin-bottom:20px"><?= htmlspecialchars($kasir['email']) ?></div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;text-align:left">
            <div style="background:var(--bg3);border-radius:var(--radius);padding:12px">
                <div style="font-size:11px;color:var(--text3);margin-bottom:4px">ID Kasir</div>
                <div style="font-family:var(--font-mono);font-weight:600;color:var(--text)">#<?= str_pad($kasir['id'],4,'0',STR_PAD_LEFT) ?></div>
            </div>
            <div style="background:var(--bg3);border-radius:var(--radius);padding:12px">
                <div style="font-size:11px;color:var(--text3);margin-bottom:4px">Bergabung</div>
                <div style="font-size:12px;font-weight:600;color:var(--text)"><?= date('d M Y', strtotime($kasir['created_at'])) ?></div>
            </div>
            <div style="background:var(--bg3);border-radius:var(--radius);padding:12px">
                <div style="font-size:11px;color:var(--text3);margin-bottom:4px">Total Transaksi</div>
                <div style="font-size:18px;font-weight:700;color:var(--gold)"><?= $kasir['trx_count'] ?></div>
            </div>
            <div style="background:var(--bg3);border-radius:var(--radius);padding:12px">
                <div style="font-size:11px;color:var(--text3);margin-bottom:4px">Total Penjualan</div>
                <div style="font-size:13px;font-weight:700;color:var(--green)">Rp <?= number_format($kasir['total_sales'],0,',','.') ?></div>
            </div>
        </div>
    </div>

    <!-- Recent Transactions -->
    <div class="card">
        <div style="padding:16px 20px;border-bottom:1px solid var(--border);font-weight:600;font-family:var(--font-display)">
            Riwayat Transaksi Terbaru
        </div>
        <div class="table-wrap">
            <table class="table">
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Total</th>
                        <th>Bayar</th>
                        <th>Kembalian</th>
                        <th>Waktu</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $hasTrx = false; while ($t = mysqli_fetch_assoc($recentTrx)): $hasTrx = true; ?>
                    <tr>
                        <td class="mono" style="color:var(--gold)"><?= htmlspecialchars($t['kode']) ?></td>
                        <td>Rp <?= number_format($t['grand_total'],0,',','.') ?></td>
                        <td style="color:var(--text2)"><?= isset($t['bayar']) && $t['bayar'] > 0 ? 'Rp ' . number_format($t['bayar'],0,',','.') : '-' ?></td>
                        <td style="color:var(--green)"><?= isset($t['kembalian']) && $t['kembalian'] > 0 ? 'Rp ' . number_format($t['kembalian'],0,',','.') : '-' ?></td>
                        <td style="color:var(--text3);font-size:12px"><?= date('d M Y H:i', strtotime($t['created_at'])) ?></td>
                    </tr>
                    <?php endwhile; ?>
                    <?php if (!$hasTrx): ?>
                    <tr><td colspan="5" style="text-align:center;color:var(--text3);padding:24px">Belum ada transaksi</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php pageEnd(); ?>
