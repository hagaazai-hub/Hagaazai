<?php
require_once '../../config.php';
requireLogin();
require_once '../../includes/layout.php';

$db = getDB();
$base = BASE_URL;
$msg = '';
$msgType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $nama = sanitize($_POST['nama'] ?? '');
        $alias = strtoupper(sanitize($_POST['alias'] ?? ''));

        if (!$nama || !$alias) {
            $msg = 'Semua field wajib diisi.'; $msgType = 'error';
        } elseif (strlen($alias) !== 3) {
            $msg = 'Alias harus tepat 3 karakter.'; $msgType = 'error';
        } else {
            if ($action === 'add') {
                $chk = mysqli_query($db, "SELECT id FROM kategori WHERE alias='$alias'");
                if (mysqli_num_rows($chk) > 0) {
                    $msg = 'Alias sudah digunakan.'; $msgType = 'error';
                } else {
                    mysqli_query($db, "INSERT INTO kategori (nama, alias) VALUES ('$nama', '$alias')");
                    $msg = 'Kategori berhasil ditambahkan.';
                }
            } else {
                $id = (int)($_POST['id'] ?? 0);
                $chk = mysqli_query($db, "SELECT id FROM kategori WHERE alias='$alias' AND id != $id");
                if (mysqli_num_rows($chk) > 0) {
                    $msg = 'Alias sudah digunakan.'; $msgType = 'error';
                } else {
                    mysqli_query($db, "UPDATE kategori SET nama='$nama', alias='$alias' WHERE id=$id");
                    $msg = 'Kategori berhasil diperbarui.';
                }
            }
        }
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        // Check if category has products
        $chk = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as c FROM produk WHERE kategori_id=$id"));
        if ($chk['c'] > 0) {
            $msg = 'Tidak bisa hapus! Masih ada '.$chk['c'].' produk di kategori ini.'; $msgType = 'error';
        } else {
            mysqli_query($db, "DELETE FROM kategori WHERE id=$id");
            $msg = 'Kategori berhasil dihapus.';
        }
    }
}

$categories = mysqli_query($db, "SELECT k.*, COUNT(p.id) as prod_count FROM kategori k LEFT JOIN produk p ON k.id=p.kategori_id GROUP BY k.id ORDER BY k.nama");

pageStart('Manajemen Kategori', 'categories');
?>

<div class="flex-between mb-6">
    <h2 style="font-family:var(--font-display);font-size:24px;font-weight:500">
        <span class="ornament"></span>Kategori
    </h2>
    <button class="btn btn-primary" onclick="openModal('addModal')">
        <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
        Tambah Kategori
    </button>
</div>

<?php if ($msg): ?>
<div class="alert alert-<?= $msgType ?>"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<div class="card" style="max-width:640px">
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nama Kategori</th>
                    <th>Alias (SKU)</th>
                    <th>Produk</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no=1; while ($k = mysqli_fetch_assoc($categories)): ?>
                <tr>
                    <td style="color:var(--text3)"><?= $no++ ?></td>
                    <td style="color:var(--text);font-weight:500"><?= htmlspecialchars($k['nama']) ?></td>
                    <td><span class="badge badge-gold"><?= $k['alias'] ?></span></td>
                    <td class="text-muted"><?= $k['prod_count'] ?> produk</td>
                    <td>
                        <div class="flex gap-2">
                            <button class="btn btn-outline btn-sm" onclick="editKat(<?= $k['id'] ?>, '<?= htmlspecialchars($k['nama'], ENT_QUOTES) ?>', '<?= $k['alias'] ?>')">Edit</button>
                            <form method="POST" onsubmit="confirmDelete(this);return false">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?= $k['id'] ?>">
                                <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add Modal -->
<div class="modal-overlay" id="addModal">
    <div class="modal">
        <div class="modal-header">
            <span class="modal-title">Tambah Kategori</span>
            <button class="btn btn-ghost btn-sm" onclick="closeModal('addModal')">✕</button>
        </div>
        <div class="modal-body">
            <form method="POST" id="addForm">
                <input type="hidden" name="action" value="add">
                <div class="form-group">
                    <label class="form-label">Nama Kategori</label>
                    <input type="text" name="nama" class="form-control" placeholder="contoh: Minuman" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Alias (3 karakter untuk SKU)</label>
                    <input type="text" name="alias" class="form-control" placeholder="MNM" maxlength="3" style="text-transform:uppercase;font-family:var(--font-mono)" required>
                    <small style="color:var(--text3);font-size:11px;margin-top:4px;display:block">Alias digunakan sebagai prefix SKU produk.</small>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button class="btn btn-ghost" onclick="closeModal('addModal')">Batal</button>
            <button class="btn btn-primary" onclick="document.getElementById('addForm').submit()">Simpan</button>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal-overlay" id="editModal">
    <div class="modal">
        <div class="modal-header">
            <span class="modal-title">Edit Kategori</span>
            <button class="btn btn-ghost btn-sm" onclick="closeModal('editModal')">✕</button>
        </div>
        <div class="modal-body">
            <form method="POST" id="editForm">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id" id="edit_id">
                <div class="form-group">
                    <label class="form-label">Nama Kategori</label>
                    <input type="text" name="nama" id="edit_nama" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Alias (3 karakter)</label>
                    <input type="text" name="alias" id="edit_alias" class="form-control" maxlength="3" style="text-transform:uppercase;font-family:var(--font-mono)" required>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button class="btn btn-ghost" onclick="closeModal('editModal')">Batal</button>
            <button class="btn btn-primary" onclick="document.getElementById('editForm').submit()">Simpan</button>
        </div>
    </div>
</div>

<script>
function editKat(id, nama, alias) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_nama').value = nama;
    document.getElementById('edit_alias').value = alias;
    openModal('editModal');
}
</script>

<?php pageEnd(); ?>
