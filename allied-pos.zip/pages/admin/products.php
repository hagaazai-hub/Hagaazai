<?php
require_once '../../config.php';
requireLogin();
require_once '../../includes/layout.php';

$db = getDB();
$base = BASE_URL;
$msg = '';
$msgType = 'success';

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $name = sanitize($_POST['name'] ?? '');
        $kategori_id = (int)($_POST['kategori_id'] ?? 0);
        $berat = (int)($_POST['berat'] ?? 0);
        $price = (float)($_POST['price'] ?? 0);
        $stock = (int)($_POST['stock'] ?? 0);
        $discount = (float)($_POST['discount'] ?? 0);

        if (!$name || !$kategori_id || !$berat || !$price) {
            $msg = 'Semua field wajib diisi.'; $msgType = 'error';
        } else {
            // Generate SKU: ALIAS-NAMEDEPAN-BERAT
            $katRes = mysqli_query($db, "SELECT alias FROM kategori WHERE id=$kategori_id");
            $katRow = mysqli_fetch_assoc($katRes);
            $alias = strtoupper($katRow['alias']);
            $namePart = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', explode(' ', $name)[0]));
            $namePart = substr($namePart, 0, 4);
            $sku = "$alias-$namePart-$berat";

            if ($action === 'add') {
                // Check SKU unique
                $chk = mysqli_query($db, "SELECT id FROM produk WHERE sku='$sku'");
                if (mysqli_num_rows($chk) > 0) {
                    $sku = $sku . '-' . rand(100,999);
                }
                mysqli_query($db, "INSERT INTO produk (name, sku, kategori_id, berat, price, stock, discount) VALUES ('$name', '$sku', $kategori_id, $berat, $price, $stock, $discount)");
                $msg = 'Produk berhasil ditambahkan.';
            } else {
                $id = (int)($_POST['id'] ?? 0);
                // Check SKU unique excluding self
                $chk = mysqli_query($db, "SELECT id FROM produk WHERE sku='$sku' AND id != $id");
                if (mysqli_num_rows($chk) > 0) {
                    $sku = $sku . '-' . rand(100,999);
                }
                mysqli_query($db, "UPDATE produk SET name='$name', sku='$sku', kategori_id=$kategori_id, berat=$berat, price=$price, stock=$stock, discount=$discount WHERE id=$id");
                $msg = 'Produk berhasil diperbarui.';
            }
        }
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        mysqli_query($db, "DELETE FROM produk WHERE id=$id");
        $msg = 'Produk berhasil dihapus.';
    }
}

// Pagination & search
$search = sanitize($_GET['q'] ?? '');
$kat_filter = (int)($_GET['kat'] ?? 0);
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 12;
$offset = ($page - 1) * $perPage;

$where = '1';
if ($search) $where .= " AND (p.name LIKE '%$search%' OR p.sku LIKE '%$search%')";
if ($kat_filter) $where .= " AND p.kategori_id = $kat_filter";

$total = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as c FROM produk p WHERE $where"))['c'];
$totalPages = max(1, ceil($total / $perPage));

$products = mysqli_query($db, "SELECT p.*, k.nama as kat_nama, k.alias FROM produk p JOIN kategori k ON p.kategori_id=k.id WHERE $where ORDER BY p.id DESC LIMIT $perPage OFFSET $offset");

$categories = mysqli_query($db, "SELECT * FROM kategori ORDER BY nama");

pageStart('Manajemen Produk', 'products');
?>

<div class="flex-between mb-6">
    <h2 style="font-family:var(--font-display);font-size:24px;font-weight:500">
        <span class="ornament"></span>Produk
    </h2>
    <button class="btn btn-primary" onclick="openModal('addModal')">
        <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
        Tambah Produk
    </button>
</div>

<?php if ($msg): ?>
<div class="alert alert-<?= $msgType ?>"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<!-- Filters -->
<div class="card mb-6">
    <form method="GET" class="flex gap-3" style="flex-wrap:wrap">
        <div class="input-group" style="flex:1;min-width:200px">
            <span class="input-icon">
                <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
            </span>
            <input type="text" name="q" class="form-control" placeholder="Cari nama / SKU..." value="<?= htmlspecialchars($search) ?>">
        </div>
        <select name="kat" class="form-control" style="width:160px">
            <option value="">Semua Kategori</option>
            <?php mysqli_data_seek($categories, 0); while ($k = mysqli_fetch_assoc($categories)): ?>
            <option value="<?= $k['id'] ?>" <?= $kat_filter==$k['id']?'selected':'' ?>><?= htmlspecialchars($k['nama']) ?></option>
            <?php endwhile; ?>
        </select>
        <button type="submit" class="btn btn-outline">Filter</button>
        <a href="<?= $base ?>/pages/admin/products.php" class="btn btn-ghost">Reset</a>
    </form>
</div>

<!-- Table -->
<div class="card">
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Produk</th>
                    <th>SKU</th>
                    <th>Kategori</th>
                    <th>Berat</th>
                    <th>Harga</th>
                    <th>Diskon</th>
                    <th>Stok</th>
                    <th>Terjual</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (mysqli_num_rows($products) === 0): ?>
                <tr><td colspan="10" style="text-align:center;padding:32px;color:var(--text3)">Tidak ada produk ditemukan</td></tr>
                <?php else: $no = $offset+1; while ($p = mysqli_fetch_assoc($products)): ?>
                <tr>
                    <td style="color:var(--text3);font-size:12px"><?= $no++ ?></td>
                    <td style="color:var(--text);font-weight:500"><?= htmlspecialchars($p['name']) ?></td>
                    <td class="mono"><?= $p['sku'] ?></td>
                    <td><span class="badge badge-blue"><?= htmlspecialchars($p['kat_nama']) ?></span></td>
                    <td class="text-muted"><?= $p['berat'] ?>g</td>
                    <td style="font-family:var(--font-mono);color:var(--gold)">Rp <?= number_format($p['price'],0,',','.') ?></td>
                    <td><?= $p['discount'] > 0 ? '<span class="badge badge-green">'.$p['discount'].'%</span>' : '<span class="text-muted">—</span>' ?></td>
                    <td>
                        <span class="badge <?= $p['stock'] == 0 ? 'badge-red' : ($p['stock'] <= 10 ? 'badge-gold' : 'badge-green') ?>">
                            <?= $p['stock'] ?>
                        </span>
                    </td>
                    <td class="text-muted"><?= $p['sold'] ?></td>
                    <td>
                        <div class="flex gap-2">
                            <button class="btn btn-outline btn-sm" onclick="editProduct(<?= htmlspecialchars(json_encode($p)) ?>)">Edit</button>
                            <form method="POST" onsubmit="confirmDelete(this);return false">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?= $p['id'] ?>">
                                <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endwhile; endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <?php if ($totalPages > 1): ?>
    <div class="pagination">
        <a href="?page=<?= max(1,$page-1) ?>&q=<?= urlencode($search) ?>&kat=<?= $kat_filter ?>" class="page-btn" <?= $page==1?'style="pointer-events:none;opacity:.4"':'' ?>>‹</a>
        <?php for ($i=1;$i<=$totalPages;$i++): ?>
        <a href="?page=<?= $i ?>&q=<?= urlencode($search) ?>&kat=<?= $kat_filter ?>" class="page-btn <?= $i==$page?'active':'' ?>"><?= $i ?></a>
        <?php endfor; ?>
        <a href="?page=<?= min($totalPages,$page+1) ?>&q=<?= urlencode($search) ?>&kat=<?= $kat_filter ?>" class="page-btn" <?= $page==$totalPages?'style="pointer-events:none;opacity:.4"':'' ?>>›</a>
    </div>
    <?php endif; ?>
</div>

<!-- Add Modal -->
<div class="modal-overlay" id="addModal">
    <div class="modal">
        <div class="modal-header">
            <span class="modal-title">Tambah Produk</span>
            <button class="btn btn-ghost btn-sm" onclick="closeModal('addModal')">✕</button>
        </div>
        <div class="modal-body">
            <form method="POST" id="addForm">
                <input type="hidden" name="action" value="add">
                <div class="grid-2">
                    <div class="form-group" style="grid-column:1/-1">
                        <label class="form-label">Nama Produk</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Kategori</label>
                        <select name="kategori_id" class="form-control" required>
                            <option value="">Pilih...</option>
                            <?php
                            mysqli_data_seek($categories, 0);
                            while ($k = mysqli_fetch_assoc($categories)):
                            ?>
                            <option value="<?= $k['id'] ?>"><?= htmlspecialchars($k['nama']) ?> (<?= $k['alias'] ?>)</option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Berat (gram)</label>
                        <input type="number" name="berat" class="form-control" min="1" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Harga (Rp)</label>
                        <input type="number" name="price" class="form-control" min="0" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Diskon (%)</label>
                        <input type="number" name="discount" class="form-control" min="0" max="100" value="0">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Stok</label>
                        <input type="number" name="stock" class="form-control" min="0" value="0" required>
                    </div>
                </div>
                <small style="color:var(--text3);font-size:11px">* SKU akan digenerate otomatis: ALIAS-NAMA-BERAT</small>
            </form>
        </div>
        <div class="modal-footer">
            <button class="btn btn-ghost" onclick="closeModal('addModal')">Batal</button>
            <button class="btn btn-primary" onclick="document.getElementById('addForm').submit()">Simpan</button>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal-overlay" id="editModal">
    <div class="modal">
        <div class="modal-header">
            <span class="modal-title">Edit Produk</span>
            <button class="btn btn-ghost btn-sm" onclick="closeModal('editModal')">✕</button>
        </div>
        <div class="modal-body">
            <form method="POST" id="editForm">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id" id="edit_id">
                <div class="grid-2">
                    <div class="form-group" style="grid-column:1/-1">
                        <label class="form-label">Nama Produk</label>
                        <input type="text" name="name" id="edit_name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Kategori</label>
                        <select name="kategori_id" id="edit_kategori" class="form-control" required>
                            <?php mysqli_data_seek($categories, 0); while ($k = mysqli_fetch_assoc($categories)): ?>
                            <option value="<?= $k['id'] ?>"><?= htmlspecialchars($k['nama']) ?> (<?= $k['alias'] ?>)</option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Berat (gram)</label>
                        <input type="number" name="berat" id="edit_berat" class="form-control" min="1" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Harga (Rp)</label>
                        <input type="number" name="price" id="edit_price" class="form-control" min="0" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Diskon (%)</label>
                        <input type="number" name="discount" id="edit_discount" class="form-control" min="0" max="100">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Stok</label>
                        <input type="number" name="stock" id="edit_stock" class="form-control" min="0" required>
                    </div>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button class="btn btn-ghost" onclick="closeModal('editModal')">Batal</button>
            <button class="btn btn-primary" onclick="document.getElementById('editForm').submit()">Simpan</button>
        </div>
    </div>
</div>

<script>
function editProduct(p) {
    document.getElementById('edit_id').value = p.id;
    document.getElementById('edit_name').value = p.name;
    document.getElementById('edit_kategori').value = p.kategori_id;
    document.getElementById('edit_berat').value = p.berat;
    document.getElementById('edit_price').value = p.price;
    document.getElementById('edit_discount').value = p.discount;
    document.getElementById('edit_stock').value = p.stock;
    openModal('editModal');
}
</script>

<?php pageEnd(); ?>
