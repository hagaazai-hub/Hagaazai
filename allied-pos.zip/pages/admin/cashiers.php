<?php
require_once '../../config.php';
requireLogin();
require_once '../../includes/layout.php';

$db = getDB();
$base = BASE_URL;
$msg = '';
$msgType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        $myId = (int)$_SESSION['cashier_id'];
        if ($id === $myId) {
            $msg = 'Tidak bisa hapus akun sendiri.'; $msgType = 'error';
        } else {
            mysqli_query($db, "DELETE FROM kasir WHERE id=$id");
            $msg = 'Kasir berhasil dihapus.';
        }
    } elseif ($action === 'reset_pass') {
        $id = (int)($_POST['id'] ?? 0);
        $newPass = $_POST['new_pass'] ?? '';
        if (strlen($newPass) < 6) {
            $msg = 'Password minimal 6 karakter.'; $msgType = 'error';
        } else {
            $hash = password_hash($newPass, PASSWORD_BCRYPT);
            mysqli_query($db, "UPDATE kasir SET password='$hash' WHERE id=$id");
            $msg = 'Password kasir berhasil direset.';
        }
    }
}

$cashiers = mysqli_query($db, "SELECT k.*, COUNT(t.id) as trx_count FROM kasir k LEFT JOIN transaksi t ON k.id=t.kasir_id GROUP BY k.id ORDER BY k.id");

pageStart('Daftar Kasir', 'cashiers');
?>

<div class="flex-between mb-6">
    <h2 style="font-family:var(--font-display);font-size:24px;font-weight:500">
        <span class="ornament"></span>Daftar Kasir
    </h2>
    <a href="<?= $base ?>/pages/auth/register.php" class="btn btn-outline" target="_blank">
        <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"/></svg>
        Tambah Kasir
    </a>
</div>

<?php if ($msg): ?>
<div class="alert alert-<?= $msgType ?>"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<div class="card">
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>ID</th>
                    <th>Transaksi</th>
                    <th>Bergabung</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no=1; while ($k = mysqli_fetch_assoc($cashiers)): $isMe = $k['id'] == $_SESSION['cashier_id']; ?>
                <tr>
                    <td style="color:var(--text3)"><?= $no++ ?></td>
                    <td>
                        <div class="flex-center gap-2">
                            <div style="width:28px;height:28px;border-radius:50%;background:var(--gold-dim);border:1px solid var(--gold);display:flex;align-items:center;justify-content:center;font-family:var(--font-display);font-size:12px;color:var(--gold);flex-shrink:0">
                                <?= strtoupper(substr($k['username'],0,1)) ?>
                            </div>
                            <span style="color:var(--text);font-weight:500"><?= htmlspecialchars($k['username']) ?></span>
                            <?php if ($isMe): ?><span class="badge badge-gold" style="font-size:10px">Saya</span><?php endif; ?>
                        </div>
                    </td>
                    <td class="text-muted"><?= htmlspecialchars($k['email']) ?></td>
                    <td class="mono">#<?= str_pad($k['id'],4,'0',STR_PAD_LEFT) ?></td>
                    <td class="text-muted"><?= $k['trx_count'] ?> trx</td>
                    <td style="color:var(--text3);font-size:12px"><?= date('d M Y', strtotime($k['created_at'])) ?></td>
                    <td>
                        <div class="flex gap-2">
                            <a href="<?= $base ?>/pages/admin/cashier_profile.php?id=<?= $k['id'] ?>" class="btn btn-outline btn-sm">Profil</a>
                        </div>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Reset Password Modal -->
<div class="modal-overlay" id="resetModal">
    <div class="modal" style="max-width:400px">
        <div class="modal-header">
            <span class="modal-title">Reset Password</span>
            <button class="btn btn-ghost btn-sm" onclick="closeModal('resetModal')">✕</button>
        </div>
        <div class="modal-body">
            <p style="color:var(--text2);margin-bottom:16px">Reset password untuk: <strong id="resetUsername" style="color:var(--gold)"></strong></p>
            <form method="POST" id="resetForm">
                <input type="hidden" name="action" value="reset_pass">
                <input type="hidden" name="id" id="resetId">
                <div class="form-group">
                    <label class="form-label">Password Baru</label>
                    <input type="password" name="new_pass" class="form-control" placeholder="Min. 6 karakter" required>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button class="btn btn-ghost" onclick="closeModal('resetModal')">Batal</button>
            <button class="btn btn-primary" onclick="document.getElementById('resetForm').submit()">Reset</button>
        </div>
    </div>
</div>

<script>
function openResetModal(id, username) {
    document.getElementById('resetId').value = id;
    document.getElementById('resetUsername').textContent = username;
    openModal('resetModal');
}
</script>

<?php pageEnd(); ?>
