<?php
require_once '../../config.php';
requireLogin();
require_once '../../includes/layout.php';

$db = getDB();
$base = BASE_URL;

$id = (int)($_GET['id'] ?? 0);
if (!$id) {
    header('Location: ' . $base . '/pages/admin/cashiers.php');
    exit;
}

$res = mysqli_query($db, "SELECT id, username, email, created_at FROM kasir WHERE id=$id");
if (!$res || mysqli_num_rows($res) === 0) {
    header('Location: ' . $base . '/pages/admin/cashiers.php');
    exit;
}

$target = mysqli_fetch_assoc($res);

// Stats
$trxRow = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as c, COALESCE(SUM(grand_total),0) as t FROM transaksi WHERE kasir_id=$id"));
$todayRow = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as c FROM transaksi WHERE kasir_id=$id AND DATE(created_at)=CURDATE()"));
$recentTrx = mysqli_query($db, "SELECT * FROM transaksi WHERE kasir_id=$id ORDER BY created_at DESC LIMIT 5");

$isMe = $target['id'] == $_SESSION['cashier_id'];

pageStart('Profile Kasir', 'cashiers');
?>

<div class="mb-6">
    <div class="flex-between">
        <h2 style="font-family:var(--font-display);font-size:24px;font-weight:500">
            <span class="ornament"></span>Profile Kasir
        </h2>
        <a href="<?= $base ?>/pages/admin/cashiers.php" class="btn btn-outline">← Kembali</a>
    </div>
</div>

<div class="grid-2" style="gap:20px;align-items:start;max-width:900px">
    <!-- Profile Card -->
    <div class="card">
        <div style="display:flex;align-items:center;gap:20px;margin-bottom:24px;padding-bottom:20px;border-bottom:1px solid var(--border)">
            <div style="width:64px;height:64px;border-radius:50%;background:var(--gold-dim);border:2px solid var(--gold);display:flex;align-items:center;justify-content:center;font-family:var(--font-display);font-size:28px;font-weight:600;color:var(--gold);flex-shrink:0">
                <?= strtoupper(substr($target['username'], 0, 1)) ?>
            </div>
            <div>
                <div style="font-family:var(--font-display);font-size:22px;font-weight:500;color:var(--text)"><?= htmlspecialchars($target['username']) ?></div>
                <div class="flex gap-2" style="margin-top:6px">
                    <span class="badge badge-gold">Kasir</span>
                    <?php if ($isMe): ?><span class="badge badge-green">Saya</span><?php endif; ?>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label class="form-label">Username</label>
            <div class="form-control" style="background:var(--bg3);color:var(--text2);cursor:default"><?= htmlspecialchars($target['username']) ?></div>
        </div>
        <div class="form-group">
            <label class="form-label">Email</label>
            <div class="form-control" style="background:var(--bg3);color:var(--text2);cursor:default"><?= htmlspecialchars($target['email']) ?></div>
        </div>
        <div class="form-group">
            <label class="form-label">ID Kasir</label>
            <div class="form-control mono" style="background:var(--bg3);color:var(--gold);cursor:default">#<?= str_pad($target['id'], 4, '0', STR_PAD_LEFT) ?></div>
        </div>
        <div class="form-group">
            <label class="form-label">Bergabung Sejak</label>
            <div class="form-control" style="background:var(--bg3);color:var(--text2);cursor:default"><?= date('d M Y', strtotime($target['created_at'])) ?></div>
        </div>

        <?php if ($isMe): ?>
            <div style="margin-top:8px">
                <a href="<?= $base ?>/pages/auth/edit_profile.php" class="btn btn-outline btn-sm">Edit Profile Saya</a>
            </div>
        <?php endif; ?>
    </div>

    <!-- Stats & Activity -->
    <div>
        <div class="stats-grid" style="grid-template-columns:1fr 1fr;margin-bottom:16px">
            <div class="stat-card">
                <div class="stat-label">Total Transaksi</div>
                <div class="stat-value"><?= $trxRow['c'] ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Total Omzet</div>
                <div class="stat-value" style="font-size:18px">Rp <?= number_format($trxRow['t'], 0, ',', '.') ?></div>
            </div>
            <div class="stat-card" style="grid-column:1/-1">
                <div class="stat-label">Transaksi Hari Ini</div>
                <div class="stat-value"><?= $todayRow['c'] ?></div>
            </div>
        </div>

        <div class="card">
            <div class="card-header" style="margin-bottom:12px;padding-bottom:12px">
                <span class="card-title" style="font-size:15px">Transaksi Terakhir</span>
            </div>
            <?php if (mysqli_num_rows($recentTrx) === 0): ?>
                <div style="text-align:center;padding:20px;color:var(--text3)">Belum ada transaksi</div>
            <?php else: ?>
                <div class="table-wrap">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Total</th>
                                <th>Waktu</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($t = mysqli_fetch_assoc($recentTrx)): ?>
                                <tr>
                                    <td class="mono"><?= $t['kode'] ?></td>
                                    <td style="color:var(--gold);font-family:var(--font-mono);font-size:12px">Rp <?= number_format($t['grand_total'], 0, ',', '.') ?></td>
                                    <td style="color:var(--text3);font-size:11px"><?= date('d/m H:i', strtotime($t['created_at'])) ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php pageEnd(); ?>