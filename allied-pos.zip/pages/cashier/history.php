<?php
require_once '../../config.php';
requireLogin();
require_once '../../includes/layout.php';

$db = getDB();
$base = BASE_URL;

$search = sanitize($_GET['q'] ?? '');
$date_from = sanitize($_GET['from'] ?? '');
$date_to = sanitize($_GET['to'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 15;
$offset = ($page - 1) * $perPage;

$where = '1';
if ($search) $where .= " AND (t.kode LIKE '%$search%' OR k.username LIKE '%$search%')";
if ($date_from) $where .= " AND DATE(t.created_at) >= '$date_from'";
if ($date_to) $where .= " AND DATE(t.created_at) <= '$date_to'";

$total = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as c FROM transaksi t JOIN kasir k ON t.kasir_id=k.id WHERE $where"))['c'];
$totalPages = max(1, ceil($total / $perPage));

$sumRow = mysqli_fetch_assoc(mysqli_query($db, "SELECT COALESCE(SUM(t.grand_total),0) as total FROM transaksi t JOIN kasir k ON t.kasir_id=k.id WHERE $where"));

$transactions = mysqli_query($db, "SELECT t.*, k.username FROM transaksi t JOIN kasir k ON t.kasir_id=k.id WHERE $where ORDER BY t.created_at DESC LIMIT $perPage OFFSET $offset");

pageStart('Riwayat Transaksi', 'history');
?>

<div class="flex-between mb-6">
    <h2 style="font-family:var(--font-display);font-size:24px;font-weight:500">
        <span class="ornament"></span>Riwayat Transaksi
    </h2>
    <div class="flex gap-2">
        <span class="badge badge-gold"><?= $total ?> transaksi</span>
        <span style="color:var(--gold);font-family:var(--font-mono);font-size:13px">Total: Rp <?= number_format($sumRow['total'],0,',','.') ?></span>
    </div>
</div>

<!-- Filters -->
<div class="card mb-6">
    <form method="GET" class="flex gap-3" style="flex-wrap:wrap;align-items:flex-end">
        <div class="input-group" style="flex:1;min-width:180px">
            <span class="input-icon">
                <svg width="13" height="13" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
            </span>
            <input type="text" name="q" class="form-control" placeholder="Kode / kasir..." value="<?= htmlspecialchars($search) ?>">
        </div>
        <div class="form-group" style="margin:0">
            <input type="date" name="from" class="form-control" value="<?= $date_from ?>" placeholder="Dari">
        </div>
        <div class="form-group" style="margin:0">
            <input type="date" name="to" class="form-control" value="<?= $date_to ?>" placeholder="Sampai">
        </div>
        <button type="submit" class="btn btn-outline">Filter</button>
        <a href="<?= $base ?>/pages/cashier/history.php" class="btn btn-ghost">Reset</a>
    </form>
</div>

<!-- Table -->
<div class="card">
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Kode</th>
                    <th>Kasir</th>
                    <th>Item</th>
                    <th>Total</th>
                    <th>Waktu</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (mysqli_num_rows($transactions) === 0): ?>
                <tr><td colspan="7" style="text-align:center;padding:32px;color:var(--text3)">Tidak ada transaksi</td></tr>
                <?php else: $no = $offset+1; while ($trx = mysqli_fetch_assoc($transactions)):
                    $products = json_decode($trx['products'], true);
                    $itemCount = count($products);
                ?>
                <tr>
                    <td style="color:var(--text3)"><?= $no++ ?></td>
                    <td class="mono"><?= $trx['kode'] ?></td>
                    <td><?= htmlspecialchars($trx['username']) ?></td>
                    <td class="text-muted"><?= $itemCount ?> item</td>
                    <td style="color:var(--gold);font-family:var(--font-mono)">Rp <?= number_format($trx['grand_total'],0,',','.') ?></td>
                    <td style="color:var(--text3);font-size:12px"><?= date('d M Y H:i', strtotime($trx['created_at'])) ?></td>
                    <td>
                        <div class="flex gap-2">
                            <button class="btn btn-outline btn-sm" onclick="viewDetail(<?= htmlspecialchars(json_encode($trx)) ?>)">Detail</button>
                            <a href="<?= $base ?>/pages/cashier/receipt.php?id=<?= $trx['id'] ?>&print=1" target="_blank" class="btn btn-ghost btn-sm">
                                <svg width="12" height="12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                                Struk
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endwhile; endif; ?>
            </tbody>
        </table>
    </div>

    <?php if ($totalPages > 1): ?>
    <div class="pagination">
        <a href="?page=<?= max(1,$page-1) ?>&q=<?= urlencode($search) ?>&from=<?= $date_from ?>&to=<?= $date_to ?>" class="page-btn" <?= $page==1?'style="pointer-events:none;opacity:.4"':'' ?>>‹</a>
        <?php for ($i=max(1,$page-2);$i<=min($totalPages,$page+2);$i++): ?>
        <a href="?page=<?= $i ?>&q=<?= urlencode($search) ?>&from=<?= $date_from ?>&to=<?= $date_to ?>" class="page-btn <?= $i==$page?'active':'' ?>"><?= $i ?></a>
        <?php endfor; ?>
        <a href="?page=<?= min($totalPages,$page+1) ?>&q=<?= urlencode($search) ?>&from=<?= $date_from ?>&to=<?= $date_to ?>" class="page-btn" <?= $page==$totalPages?'style="pointer-events:none;opacity:.4"':'' ?>>›</a>
    </div>
    <?php endif; ?>
</div>

<!-- Detail Modal -->
<div class="modal-overlay" id="detailModal">
    <div class="modal" style="max-width:480px">
        <div class="modal-header">
            <span class="modal-title" id="detailTitle">Detail Transaksi</span>
            <button class="btn btn-ghost btn-sm" onclick="closeModal('detailModal')">✕</button>
        </div>
        <div class="modal-body" id="detailBody"></div>
        <div class="modal-footer">
            <button class="btn btn-ghost" onclick="closeModal('detailModal')">Tutup</button>
            <a id="detailPrintBtn" href="#" target="_blank" class="btn btn-outline">
                <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                Download Struk
            </a>
        </div>
    </div>
</div>

<script>
function viewDetail(trx) {
    var products = typeof trx.products === 'string' ? JSON.parse(trx.products) : trx.products;
    document.getElementById('detailTitle').textContent = trx.kode;

    var html = '<div style="margin-bottom:16px">' +
        '<div class="flex-between" style="margin-bottom:6px"><span class="text-muted">Kasir:</span><strong>' + trx.username + '</strong></div>' +
        '<div class="flex-between" style="margin-bottom:6px"><span class="text-muted">Waktu:</span><span style="font-size:13px">' + trx.created_at + '</span></div>' +
        '</div><div class="divider"></div>';

    html += '<div class="table-wrap"><table class="table" style="font-size:13px"><thead><tr><th>Produk</th><th>Qty</th><th>Harga</th><th>Subtotal</th></tr></thead><tbody>';

    products.forEach(function(p) {
        html += '<tr>' +
            '<td><div style="font-weight:500;color:var(--text)">' + p.name + '</div><div style="font-size:11px;color:var(--text3)">' + p.sku + '</div></td>' +
            '<td style="color:var(--text2)">' + p.qty + '</td>' +
            '<td style="font-family:var(--font-mono);font-size:12px">Rp ' + parseInt(p.final_price).toLocaleString('id-ID') + '</td>' +
            '<td style="color:var(--gold);font-family:var(--font-mono);font-size:12px">Rp ' + parseInt(p.subtotal).toLocaleString('id-ID') + '</td>' +
            '</tr>';
    });

    html += '</tbody></table></div>';
    html += '<div class="divider"></div>';
    html += '<div class="flex-between" style="font-family:var(--font-display);font-size:18px"><span>Grand Total</span><span style="color:var(--gold)">Rp ' + parseInt(trx.grand_total).toLocaleString('id-ID') + '</span></div>';

    document.getElementById('detailBody').innerHTML = html;
    document.getElementById('detailPrintBtn').href = '<?= $base ?>/pages/cashier/receipt.php?id=' + trx.id + '&print=1';
    openModal('detailModal');
}
</script>

<?php pageEnd(); ?>
