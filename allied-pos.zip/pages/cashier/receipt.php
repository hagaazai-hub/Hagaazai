<?php
require_once '../../config.php';
requireLogin();

$db = getDB();
$id = (int)($_GET['id'] ?? 0);
$print = isset($_GET['print']);

$res = mysqli_query($db, "SELECT t.*, k.username FROM transaksi t JOIN kasir k ON t.kasir_id=k.id WHERE t.id=$id");
if (!$res || mysqli_num_rows($res) === 0) {
    die('Transaksi tidak ditemukan.');
}

$trx = mysqli_fetch_assoc($res);
$products = json_decode($trx['products'], true);
$base = BASE_URL;
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Struk <?= $trx['kode'] ?></title>
<link rel="stylesheet" href="<?= $base ?>/css/style.css">
<style>
body { background: #f5f5f5; display: flex; justify-content: center; padding: 30px 16px; }
.receipt-wrap { box-shadow: 0 2px 20px rgba(0,0,0,0.15); }
.print-btn { display: flex; justify-content: center; gap: 12px; margin: 20px 0; }
@media print {
    body { background: #fff; padding: 0; }
    .print-btn { display: none; }
    .receipt-wrap { box-shadow: none; }
}
</style>
</head>
<body>
<div>
    <div class="print-btn">
        <button onclick="window.print()" style="padding:8px 20px;border-radius:8px;background:#1a1a2e;color:#c9a84c;border:1px solid #c9a84c;cursor:pointer;font-size:14px">🖨️ Print</button>
        <a href="<?= $base ?>/pages/cashier/history.php" style="padding:8px 20px;border-radius:8px;background:transparent;color:#666;border:1px solid #ccc;text-decoration:none;font-size:14px">← Kembali</a>
    </div>

    <div class="receipt-wrap" id="receiptPrint">
        <div class="receipt-store">
            <h2><?= STORE_NAME ?></h2>
            <p><?= STORE_LOCATION ?></p>
        </div>
        <hr class="receipt-divider">
        <div style="font-size:11px;font-family:monospace;padding:0 8px">
            <div style="display:flex;justify-content:space-between">
                <span>No</span>
                <span><?= $trx['kode'] ?></span>
            </div>
            <div style="display:flex;justify-content:space-between">
                <span>Kasir</span>
                <span><?= htmlspecialchars($trx['username']) ?></span>
            </div>
            <div style="display:flex;justify-content:space-between">
                <span>Waktu</span>
                <span><?= date('d/m/Y H:i', strtotime($trx['created_at'])) ?></span>
            </div>
        </div>
        <hr class="receipt-divider">
        <div class="receipt-items" style="padding:0 8px">
            <table>
                <?php foreach ($products as $p): ?>
                <tr>
                    <td colspan="3"><strong><?= htmlspecialchars($p['name']) ?></strong></td>
                </tr>
                <tr>
                    <td><?= $p['qty'] ?>x Rp <?= number_format($p['final_price'],0,',','.') ?></td>
                    <td></td>
                    <td style="text-align:right">Rp <?= number_format($p['subtotal'],0,',','.') ?></td>
                </tr>
                <?php if ($p['discount'] > 0): ?>
                <tr>
                    <td colspan="3" style="color:#888;font-size:10px;padding-top:0">  Diskon <?= $p['discount'] ?>%: -Rp <?= number_format($p['price']*$p['qty']-$p['subtotal'],0,',','.') ?></td>
                </tr>
                <?php endif; ?>
                <?php endforeach; ?>
            </table>
        </div>
        <div class="receipt-total" style="padding:0 8px">
            <div class="row grand">
                <span>TOTAL</span>
                <span>Rp <?= number_format($trx['grand_total'],0,',','.') ?></span>
            </div>
        </div>
        <hr class="receipt-divider">
        <div class="receipt-footer">
            <p>Terima kasih telah berbelanja</p>
            <p>di <?= STORE_NAME ?></p>
            <p style="margin-top:8px;font-size:10px;color:#aaa"><?= STORE_LOCATION ?></p>
        </div>
    </div>
</div>
<?php if ($print): ?>
<script>
window.onload = function() { window.print(); }
</script>
<?php endif; ?>
</body>
</html>
