<?php
require_once '../../config.php';
requireLogin();
require_once '../../includes/layout.php';

$db = getDB();
$base = BASE_URL;
$cashier = getCurrentCashier();

// Handle transaction submit
$trxResult = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['checkout'])) {
    $cartJson = $_POST['cart_data'] ?? '[]';
    $cart = json_decode($cartJson, true);
    $bayar = (float)($_POST['bayar'] ?? 0);

    if (!empty($cart)) {
        $grand_total = 0;
        $products_data = [];
        $valid = true;

        foreach ($cart as $item) {
            $pid = (int)$item['id'];
            $qty = (int)$item['qty'];
            $res = mysqli_query($db, "SELECT * FROM produk WHERE id=$pid AND stock >= $qty");
            $prod = mysqli_fetch_assoc($res);
            if (!$prod) { $valid = false; break; }

            $price = $prod['price'];
            $disc = $prod['discount'];
            $discAmount = $price * $disc / 100;
            $finalPrice = $price - $discAmount;
            $subtotal = $finalPrice * $qty;
            $grand_total += $subtotal;

            $products_data[] = [
                'id' => $prod['id'],
                'name' => $prod['name'],
                'sku' => $prod['sku'],
                'qty' => $qty,
                'price' => $price,
                'discount' => $disc,
                'final_price' => $finalPrice,
                'subtotal' => $subtotal
            ];
        }

        if ($valid && !empty($products_data)) {
            $kode = generateTRX();
            $kasir_id = (int)$_SESSION['cashier_id'];
            $productsJson = mysqli_real_escape_string($db, json_encode($products_data));
            $kembalian = max(0, $bayar - $grand_total);

            mysqli_query($db, "INSERT INTO transaksi (kode, kasir_id, grand_total, bayar, kembalian, products) VALUES ('$kode', $kasir_id, $grand_total, $bayar, $kembalian, '$productsJson')");
            $trx_id = mysqli_insert_id($db);

            // Update stock & sold
            foreach ($products_data as $p) {
                $pid = (int)$p['id'];
                $qty = (int)$p['qty'];
                mysqli_query($db, "UPDATE produk SET stock=stock-$qty, sold=sold+$qty WHERE id=$pid");
            }

            $trxResult = [
                'id' => $trx_id,
                'kode' => $kode,
                'grand_total' => $grand_total,
                'bayar' => $bayar,
                'kembalian' => $kembalian,
                'products' => $products_data,
                'kasir' => $cashier['username'],
                'time' => date('d M Y H:i:s')
            ];
        }
    }
}

// Get products grouped by category
$categories = mysqli_query($db, "SELECT * FROM kategori ORDER BY nama");
$products = mysqli_query($db, "SELECT p.*, k.nama as kat_nama, k.id as kat_id FROM produk p JOIN kategori k ON p.kategori_id=k.id ORDER BY k.nama, p.name");

$allProducts = [];
while ($p = mysqli_fetch_assoc($products)) {
    $allProducts[] = $p;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Kasir / POS — Allied Shopping</title>
<link rel="stylesheet" href="<?= $base ?>/css/style.css">
<script>window.BASE_URL = '<?= $base ?>';</script>
</head>
<body>
<div class="layout">
<?php
$GLOBALS['_nav_dashboard'] = '';
$GLOBALS['_nav_pos'] = 'active';
$GLOBALS['_nav_history'] = '';
$GLOBALS['_nav_products'] = '';
$GLOBALS['_nav_categories'] = '';
$GLOBALS['_nav_cashiers'] = '';
$GLOBALS['_nav_profile'] = '';
renderSidebar('pos');
?>
<div class="main">
<?php renderTopbar('Kasir / POS'); ?>
<div style="padding:20px;flex:1;overflow:hidden">
    <?php if ($trxResult): ?>
    <!-- Success Receipt Modal -->
    <div class="modal-overlay active" id="receiptModal">
        <div class="modal" style="max-width:440px">
            <div class="modal-header">
                <span class="modal-title text-green">✓ Transaksi Berhasil</span>
                <button type="button" class="btn btn-ghost btn-sm" onclick="location.href=location.href.split('?')[0]">✕</button>
            </div>
            <div class="modal-body" style="padding:0">
                <div id="receiptContent">
                    <div class="receipt-wrap">
                        <div class="receipt-store">
                            <h2><?= STORE_NAME ?></h2>
                            <p><?= STORE_LOCATION ?></p>
                        </div>
                        <hr class="receipt-divider">
                        <div style="font-size:11px;font-family:monospace">
                            <div>No: <?= $trxResult['kode'] ?></div>
                            <div>Kasir: <?= htmlspecialchars($trxResult['kasir']) ?></div>
                            <div>Waktu: <?= $trxResult['time'] ?></div>
                        </div>
                        <hr class="receipt-divider">
                        <div class="receipt-items">
                            <table>
                                <?php foreach ($trxResult['products'] as $p): ?>
                                <tr>
                                    <td colspan="3" style="padding-bottom:2px"><strong><?= htmlspecialchars($p['name']) ?></strong></td>
                                </tr>
                                <tr>
                                    <td><?= $p['qty'] ?>x</td>
                                    <td>Rp <?= number_format($p['final_price'],0,',','.') ?></td>
                                    <td style="text-align:right">Rp <?= number_format($p['subtotal'],0,',','.') ?></td>
                                </tr>
                                <?php if ($p['discount'] > 0): ?>
                                <tr><td colspan="3" style="color:#888;font-size:10px">Diskon <?= $p['discount'] ?>%</td></tr>
                                <?php endif; ?>
                                <?php endforeach; ?>
                            </table>
                        </div>
                        <div class="receipt-total">
                            <div class="row grand">
                                <span>TOTAL</span>
                                <span>Rp <?= number_format($trxResult['grand_total'],0,',','.') ?></span>
                            </div>
                            <?php if ($trxResult['bayar'] > 0): ?>
                            <div class="row" style="font-size:13px;padding:4px 0">
                                <span style="color:var(--text2)">Bayar</span>
                                <span style="color:var(--text2)">Rp <?= number_format($trxResult['bayar'],0,',','.') ?></span>
                            </div>
                            <div class="row" style="font-size:14px;padding:4px 0">
                                <span style="color:var(--green);font-weight:600">Kembalian</span>
                                <span style="color:var(--green);font-weight:600">Rp <?= number_format($trxResult['kembalian'],0,',','.') ?></span>
                            </div>
                            <?php endif; ?>
                        </div>
                        <hr class="receipt-divider">
                        <div class="receipt-footer">
                            <p>Terima kasih telah berbelanja</p>
                            <p>di <?= STORE_NAME ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-outline" onclick="printReceipt('receiptContent')">
                    <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
                    Print
                </button>
                <a href="<?= $base ?>/pages/cashier/receipt.php?id=<?= $trxResult['id'] ?>&print=1" target="_blank" class="btn btn-outline">
                    <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                    Download PDF
                </a>
                <button type="button" class="btn btn-primary" onclick="location.href=location.href.split('?')[0]">Transaksi Baru</button>
            </div>
        </div>
    </div>
    <?php endif; ?>


    <!-- Payment Modal -->
    <div class="modal-overlay" id="paymentModal">
        <div class="modal" style="max-width:380px">
            <div class="modal-header">
                <span class="modal-title">Pembayaran</span>
                <button type="button" class="btn btn-ghost btn-sm" onclick="closeModal('paymentModal')">✕</button>
            </div>
            <div class="modal-body">
                <div style="margin-bottom:14px">
                    <div style="color:var(--text2);font-size:13px;margin-bottom:4px">Total Belanja</div>
                    <div style="font-size:24px;font-weight:700;font-family:var(--font-display);color:var(--gold)" id="payTotalDisplay">Rp 0</div>
                </div>
                <div class="form-group">
                    <label class="form-label">Uang Bayar (Rp)</label>
                    <input type="number" id="bayarField" class="form-control" placeholder="Masukkan jumlah uang..." min="0" oninput="calcKembalian()" style="font-size:16px">
                </div>
                <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px" id="quickPay"></div>
                <div style="background:var(--bg3);border-radius:var(--radius);padding:12px;display:flex;justify-content:space-between;align-items:center">
                    <span style="color:var(--text2)">Kembalian</span>
                    <span style="font-size:20px;font-weight:700;color:var(--green)" id="kembalianDisplay">Rp 0</span>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-ghost" onclick="closeModal('paymentModal')">Batal</button>
                <button type="button" class="btn btn-success" id="confirmPayBtn" onclick="confirmPayment()" disabled>Konfirmasi Bayar</button>
            </div>
        </div>
    </div>
    <div class="pos-layout">
        <div class="pos-left" style="background:var(--bg2);border:1px solid var(--border);border-radius:var(--radius-lg);overflow:hidden">
            <!-- Search by SKU -->
            <div class="pos-search">
                <div class="search-sku">
                    <div class="input-group" style="flex:1">
                        <span class="input-icon">
                            <svg width="13" height="13" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                        </span>
                        <input type="text" id="skuInput" class="form-control" placeholder="Scan / ketik SKU lalu Enter..." style="font-family:var(--font-mono)">
                    </div>
                    <button class="btn btn-primary" onclick="addBySKU()">Tambah</button>
                </div>
            </div>

            <!-- Category Filter -->
            <div class="filter-pills">
                <button class="pill active" onclick="filterCategory('all', this)">Semua</button>
                <?php foreach ($allProducts as $p): ?>
                <?php endforeach; ?>
                <?php
                mysqli_data_seek($categories, 0);
                while ($cat = mysqli_fetch_assoc($categories)):
                ?>
                <button class="pill" onclick="filterCategory('<?= $cat['id'] ?>', this)"><?= htmlspecialchars($cat['nama']) ?></button>
                <?php endwhile; ?>
            </div>

            <!-- Product Grid -->
            <div class="products-grid" id="productsGrid">
                <?php foreach ($allProducts as $p):
                    $finalPrice = $p['price'] * (1 - $p['discount']/100);
                ?>
                <div class="product-tile <?= $p['stock'] <= 0 ? 'out-of-stock' : '' ?>"
                     data-id="<?= $p['id'] ?>"
                     data-sku="<?= $p['sku'] ?>"
                     data-name="<?= htmlspecialchars($p['name'], ENT_QUOTES) ?>"
                     data-price="<?= $p['price'] ?>"
                     data-discount="<?= $p['discount'] ?>"
                     data-finalprice="<?= $finalPrice ?>"
                     data-stock="<?= $p['stock'] ?>"
                     data-kat="<?= $p['kat_id'] ?>"
                     onclick="addToCart(this)">
                    <div class="p-name"><?= htmlspecialchars($p['name']) ?></div>
                    <div class="p-sku"><?= $p['sku'] ?></div>
                    <div class="p-price">Rp <?= number_format($finalPrice,0,',','.') ?></div>
                    <?php if ($p['discount'] > 0): ?>
                    <div style="font-size:10px;color:var(--green);margin-top:2px">Diskon <?= $p['discount'] ?>%</div>
                    <?php endif; ?>
                    <div class="p-stock">Stok: <?= $p['stock'] ?></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Right: Cart -->
        <div class="pos-right">
            <div class="cart-header">
                <span class="cart-header-title">Keranjang</span>
                <button class="btn btn-ghost btn-sm" onclick="clearCart()" title="Kosongkan">
                    <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                </button>
            </div>

            <div class="cart-items" id="cartItems">
                <div class="empty-state" id="cartEmpty">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
                    <p>Keranjang kosong</p>
                </div>
            </div>

            <div class="cart-summary">
                <div class="summary-row">
                    <span>Subtotal</span>
                    <span id="subtotalDisplay">Rp 0</span>
                </div>
                <div class="summary-row">
                    <span>Diskon</span>
                    <span id="discountDisplay" style="color:var(--green)">- Rp 0</span>
                </div>
                <div class="summary-row total">
                    <span>Total</span>
                    <span class="total-amount" id="totalDisplay">Rp 0</span>
                </div>

                <form method="POST" id="checkoutForm" style="margin-top:14px">
                    <input type="hidden" name="checkout" value="1">
                    <input type="hidden" name="cart_data" id="cartDataInput">
                    <input type="hidden" name="bayar" id="bayarInput" value="0">
                    <button type="button" class="btn btn-success w-full btn-lg" style="justify-content:center;font-size:15px" id="checkoutBtn" disabled onclick="openPaymentModal()">
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                        Bayar
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
</div></div>

<script src="<?= $base ?>/js/app.js"></script>
<script>
var cart = {};
var allProducts = <?= json_encode(array_map(function($p) {
    return [
        'id' => $p['id'],
        'sku' => $p['sku'],
        'name' => $p['name'],
        'price' => (float)$p['price'],
        'discount' => (float)$p['discount'],
        'final_price' => (float)$p['price'] * (1 - (float)$p['discount']/100),
        'stock' => (int)$p['stock']
    ];
}, $allProducts)) ?>;

function addToCart(el) {
    var id = el.dataset.id;
    var name = el.dataset.name;
    var price = parseFloat(el.dataset.price);
    var discount = parseFloat(el.dataset.discount);
    var finalPrice = parseFloat(el.dataset.finalprice);
    var stock = parseInt(el.dataset.stock);
    var sku = el.dataset.sku;

    if (cart[id]) {
        if (cart[id].qty >= cart[id].stock) {
            alert('Stok tidak cukup!'); return;
        }
        cart[id].qty++;
    } else {
        cart[id] = { id: id, sku: sku, name: name, price: price, discount: discount, final_price: finalPrice, qty: 1, stock: stock };
    }
    renderCart();
}

function addBySKU() {
    var sku = document.getElementById('skuInput').value.trim().toUpperCase();
    if (!sku) return;
    var found = null;
    for (var i=0; i<allProducts.length; i++) {
        if (allProducts[i].sku.toUpperCase() === sku) { found = allProducts[i]; break; }
    }
    if (!found) {
        document.getElementById('skuInput').style.borderColor = 'var(--red)';
        setTimeout(function(){ document.getElementById('skuInput').style.borderColor = ''; }, 1500);
        return;
    }
    if (found.stock <= 0) { alert('Stok habis!'); return; }
    if (cart[found.id]) {
        if (cart[found.id].qty >= found.stock) { alert('Stok tidak cukup!'); return; }
        cart[found.id].qty++;
    } else {
        cart[found.id] = { id: found.id, sku: found.sku, name: found.name, price: found.price, discount: found.discount, final_price: found.final_price, qty: 1, stock: found.stock };
    }
    document.getElementById('skuInput').value = '';
    renderCart();
}

document.getElementById('skuInput').addEventListener('keydown', function(e) {
    if (e.key === 'Enter') { e.preventDefault(); addBySKU(); }
});

function changeQty(id, delta) {
    if (!cart[id]) return;
    cart[id].qty += delta;
    if (cart[id].qty <= 0) { delete cart[id]; }
    else if (cart[id].qty > cart[id].stock) { cart[id].qty = cart[id].stock; }
    renderCart();
}

function removeItem(id) {
    delete cart[id];
    renderCart();
}

function clearCart() {
    cart = {};
    renderCart();
}

function renderCart() {
    var container = document.getElementById('cartItems');
    var empty = document.getElementById('cartEmpty');
    var keys = Object.keys(cart);

    if (keys.length === 0) {
        if (!empty) {
            container.innerHTML = '<div class="empty-state" id="cartEmpty"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/></svg><p>Keranjang kosong</p></div>';
        }
        document.getElementById('checkoutBtn').disabled = true;
        document.getElementById('subtotalDisplay').textContent = 'Rp 0';
        document.getElementById('discountDisplay').textContent = '- Rp 0';
        document.getElementById('totalDisplay').textContent = 'Rp 0';
        return;
    }

    var html = '';
    var subtotalNoDisc = 0;
    var totalDisc = 0;
    var grandTotal = 0;

    keys.forEach(function(id) {
        var item = cart[id];
        var sub = item.final_price * item.qty;
        var oriSub = item.price * item.qty;
        subtotalNoDisc += oriSub;
        totalDisc += (oriSub - sub);
        grandTotal += sub;

        html += '<div class="cart-item">' +
            '<div class="cart-item-info">' +
                '<div class="cart-item-name">' + item.name + '</div>' +
                '<div class="cart-item-sku">' + item.sku + '</div>' +
                '<div class="cart-item-price">Rp ' + formatRupiah2(item.final_price) + ' x' + item.qty + '</div>' +
            '</div>' +
            '<div>' +
                '<div class="qty-control">' +
                    '<button class="qty-btn" onclick="changeQty(' + id + ', -1)">−</button>' +
                    '<span class="qty-val">' + item.qty + '</span>' +
                    '<button class="qty-btn" onclick="changeQty(' + id + ', 1)">+</button>' +
                '</div>' +
                '<div style="text-align:center;margin-top:4px;font-family:var(--font-mono);font-size:12px;color:var(--gold)">Rp ' + formatRupiah2(sub) + '</div>' +
            '</div>' +
        '</div>';
    });

    container.innerHTML = html;
    document.getElementById('subtotalDisplay').textContent = 'Rp ' + formatRupiah2(subtotalNoDisc);
    document.getElementById('discountDisplay').textContent = '- Rp ' + formatRupiah2(totalDisc);
    document.getElementById('totalDisplay').textContent = 'Rp ' + formatRupiah2(grandTotal);
    document.getElementById('checkoutBtn').disabled = false;

    // Prepare cart data for form
    var cartArr = keys.map(function(id) { return { id: id, qty: cart[id].qty }; });
    document.getElementById('cartDataInput').value = JSON.stringify(cartArr);
}

function formatRupiah2(n) {
    return parseInt(n).toLocaleString('id-ID');
}

function filterCategory(katId, btn) {
    document.querySelectorAll('.filter-pills .pill').forEach(function(p) { p.classList.remove('active'); });
    btn.classList.add('active');

    document.querySelectorAll('.product-tile').forEach(function(tile) {
        if (katId === 'all' || tile.dataset.kat === katId) {
            tile.style.display = '';
        } else {
            tile.style.display = 'none';
        }
    });
}

var _currentTotal = 0;

function openPaymentModal() {
    if (Object.keys(cart).length === 0) return;
    _currentTotal = 0;
    var keys = Object.keys(cart);
    keys.forEach(function(id) {
        _currentTotal += cart[id].final_price * cart[id].qty;
    });
    document.getElementById('payTotalDisplay').textContent = 'Rp ' + formatRupiah2(_currentTotal);
    document.getElementById('bayarField').value = '';
    document.getElementById('kembalianDisplay').textContent = 'Rp 0';
    document.getElementById('confirmPayBtn').disabled = true;

    // Quick pay buttons
    var qp = document.getElementById('quickPay');
    qp.innerHTML = '';
    var nominals = [5000, 10000, 20000, 50000, 100000];
    var suitable = nominals.filter(function(n) { return n >= _currentTotal; }).slice(0,3);
    // round up to nearest
    var rounded = Math.ceil(_currentTotal / 1000) * 1000;
    if (suitable.indexOf(rounded) === -1 && rounded !== _currentTotal) suitable.unshift(rounded);
    suitable.slice(0,4).forEach(function(n) {
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'btn btn-outline btn-sm';
        btn.textContent = 'Rp ' + formatRupiah2(n);
        btn.onclick = function() {
            document.getElementById('bayarField').value = n;
            calcKembalian();
        };
        qp.appendChild(btn);
    });

    openModal('paymentModal');
}

function calcKembalian() {
    var bayar = parseFloat(document.getElementById('bayarField').value) || 0;
    var kembalian = bayar - _currentTotal;
    if (kembalian < 0) {
        document.getElementById('kembalianDisplay').textContent = '- Rp ' + formatRupiah2(Math.abs(kembalian));
        document.getElementById('kembalianDisplay').style.color = 'var(--red)';
        document.getElementById('confirmPayBtn').disabled = true;
    } else {
        document.getElementById('kembalianDisplay').textContent = 'Rp ' + formatRupiah2(kembalian);
        document.getElementById('kembalianDisplay').style.color = 'var(--green)';
        document.getElementById('confirmPayBtn').disabled = false;
    }
}

function confirmPayment() {
    var bayar = parseFloat(document.getElementById('bayarField').value) || 0;
    if (bayar < _currentTotal) return;
    document.getElementById('bayarInput').value = bayar;
    closeModal('paymentModal');
    document.getElementById('checkoutForm').submit();
}
</script>
</body>
</html>
