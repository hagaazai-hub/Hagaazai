<?php
require_once '../../config.php';
requireLogin();
require_once '../../includes/layout.php';

$cashier = getCurrentCashier();
$base = BASE_URL;

pageStart('Profile', 'profile');
?>

<div class="mb-6">
    <div class="flex-between">
        <h2 style="font-family:var(--font-display);font-size:24px;font-weight:500">
            <span class="ornament"></span>Profile Saya
        </h2>
        <a href="<?= $base ?>/pages/auth/edit_profile.php" class="btn btn-outline">
            <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
            Edit Profile
        </a>
    </div>
</div>

<div style="max-width:560px">
    <div class="card">
        <div style="display:flex;align-items:center;gap:20px;margin-bottom:24px;padding-bottom:20px;border-bottom:1px solid var(--border)">
            <div style="width:64px;height:64px;border-radius:50%;background:var(--gold-dim);border:2px solid var(--gold);display:flex;align-items:center;justify-content:center;font-family:var(--font-display);font-size:28px;font-weight:600;color:var(--gold);flex-shrink:0">
                <?= strtoupper(substr($cashier['username'], 0, 1)) ?>
            </div>
            <div>
                <div style="font-family:var(--font-display);font-size:22px;font-weight:500;color:var(--text)"><?= htmlspecialchars($cashier['username']) ?></div>
                <div class="badge badge-gold" style="margin-top:6px">Kasir</div>
            </div>
        </div>

        <div class="form-group">
            <label class="form-label">Username</label>
            <div class="form-control" style="background:var(--bg3);color:var(--text2);cursor:default"><?= htmlspecialchars($cashier['username']) ?></div>
        </div>
        <div class="form-group">
            <label class="form-label">Email</label>
            <div class="form-control" style="background:var(--bg3);color:var(--text2);cursor:default"><?= htmlspecialchars($cashier['email']) ?></div>
        </div>
        <div class="form-group">
            <label class="form-label">ID Kasir</label>
            <div class="form-control mono" style="background:var(--bg3);color:var(--gold);cursor:default">#<?= str_pad($cashier['id'], 4, '0', STR_PAD_LEFT) ?></div>
        </div>

        <div style="margin-top:16px">
            <a href="<?= $base ?>/pages/auth/change_password.php" class="btn btn-outline">
                <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
                Ganti Password
            </a>
        </div>
    </div>
</div>

<?php pageEnd(); ?>
