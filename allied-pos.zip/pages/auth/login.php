<?php
require_once '../../config.php';

if (isLoggedIn()) {
    header('Location: ' . BASE_URL . '/index.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username && $password) {
        $db = getDB();
        $res = mysqli_query($db, "SELECT * FROM kasir WHERE username = '$username' OR email = '$username' LIMIT 1");
        $user = mysqli_fetch_assoc($res);

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['cashier_id'] = $user['id'];
            $_SESSION['cashier_username'] = $user['username'];
            header('Location: ' . BASE_URL . '/index.php');
            exit;
        } else {
            $error = 'Username/email atau password salah.';
        }
    } else {
        $error = 'Semua field wajib diisi.';
    }
}
$base = BASE_URL;
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login — Allied Shopping POS</title>
<link rel="stylesheet" href="<?= $base ?>/css/style.css">
</head>
<body>
<div class="auth-page">
    <div class="auth-card">
        <div class="auth-logo">
            <div class="brand">Allied Shopping</div>
            <div class="sub">Point of Sale System</div>
            <div class="auth-divider"></div>
        </div>

        <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label class="form-label">Username / Email</label>
                <input type="text" name="username" class="form-control" placeholder="Masukkan username" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required autofocus>
            </div>
            <div class="form-group">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" placeholder="Masukkan password" required>
            </div>
            <button type="submit" class="btn btn-primary w-full btn-lg" style="justify-content:center;margin-top:8px">
                Masuk
            </button>
        </form>

        <div style="text-align:center;margin-top:20px;font-size:13px;color:var(--text3)">
            Belum punya akun?
            <a href="<?= $base ?>/pages/auth/register.php">Daftar</a>
        </div>
    </div>
</div>
</body>
</html>
