<?php
require_once '../../config.php';
requireLogin();
require_once '../../includes/layout.php';

$cashier = getCurrentCashier();
$base = BASE_URL;
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username'] ?? '');
    $email = sanitize($_POST['email'] ?? '');

    if (!$username || !$email) {
        $error = 'Semua field wajib diisi.';
    } else {
        $db = getDB();
        $id = (int)$_SESSION['cashier_id'];
        $check = mysqli_query($db, "SELECT id FROM kasir WHERE (username='$username' OR email='$email') AND id != $id");
        if (mysqli_num_rows($check) > 0) {
            $error = 'Username atau email sudah digunakan kasir lain.';
        } else {
            mysqli_query($db, "UPDATE kasir SET username='$username', email='$email' WHERE id=$id");
            $_SESSION['cashier_username'] = $username;
            $success = 'Profile berhasil diperbarui.';
            $cashier = getCurrentCashier();
        }
    }
}

pageStart('Edit Profile', 'profile');
?>

<div class="mb-6">
    <div class="flex-between">
        <h2 style="font-family:var(--font-display);font-size:24px;font-weight:500">
            <span class="ornament"></span>Edit Profile
        </h2>
        <a href="<?= $base ?>/pages/auth/profile.php" class="btn btn-outline">← Kembali</a>
    </div>
</div>

<div style="max-width:560px">
    <div class="card">
        <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label class="form-label">Username</label>
                <input type="text" name="username" class="form-control" value="<?= htmlspecialchars($cashier['username']) ?>" required>
            </div>
            <div class="form-group">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($cashier['email']) ?>" required>
            </div>
            <div class="flex gap-2" style="margin-top:20px">
                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                <a href="<?= $base ?>/pages/auth/profile.php" class="btn btn-ghost">Batal</a>
            </div>
        </form>
    </div>
</div>

<?php pageEnd(); ?>
