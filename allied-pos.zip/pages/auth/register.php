<?php
require_once '../../config.php';

if (isLoggedIn()) {
    header('Location: ' . BASE_URL . '/index.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $password2 = $_POST['password2'] ?? '';
    $secret = $_POST['secret'] ?? '';

    if (!$username || !$email || !$password || !$secret) {
        $error = 'Semua field wajib diisi.';
    } elseif ($password !== $password2) {
        $error = 'Konfirmasi password tidak cocok.';
    } elseif (strlen($password) < 6) {
        $error = 'Password minimal 6 karakter.';
    } elseif ($secret !== REGISTER_SECRET) {
        $error = 'Secret key tidak valid.';
    } else {
        $db = getDB();
        $check = mysqli_query($db, "SELECT id FROM kasir WHERE username='$username' OR email='$email'");
        if (mysqli_num_rows($check) > 0) {
            $error = 'Username atau email sudah digunakan.';
        } else {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            mysqli_query($db, "INSERT INTO kasir (username, email, password) VALUES ('$username', '$email', '$hash')");
            $success = 'Akun berhasil dibuat! Silakan login.';
        }
    }
}
$base = BASE_URL;
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Daftar — Allied Shopping POS</title>
<link rel="stylesheet" href="<?= $base ?>/css/style.css">
</head>
<body>
<div class="auth-page">
    <div class="auth-card">
        <div class="auth-logo">
            <div class="brand">Allied Shopping</div>
            <div class="sub">Registrasi Kasir</div>
            <div class="auth-divider"></div>
        </div>

        <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label class="form-label">Username</label>
                <input type="text" name="username" class="form-control" placeholder="username" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
            </div>
            <div class="form-group">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" placeholder="email@example.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
            </div>
            <div class="grid-2">
                <div class="form-group">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Min. 6 karakter" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Konfirmasi</label>
                    <input type="password" name="password2" class="form-control" placeholder="Ulangi password" required>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Secret Key</label>
                <input type="password" name="secret" class="form-control" placeholder="Masukkan secret key" required>
                <small style="color:var(--text3);font-size:11px;margin-top:4px;display:block">Hubungi admin untuk mendapatkan secret key.</small>
            </div>
            <button type="submit" class="btn btn-primary w-full btn-lg" style="justify-content:center;margin-top:8px">
                Daftar
            </button>
        </form>

        <div style="text-align:center;margin-top:20px;font-size:13px;color:var(--text3)">
            Sudah punya akun?
            <a href="<?= $base ?>/pages/auth/login.php">Login</a>
        </div>
    </div>
</div>
</body>
</html>
