<?php
require_once '../../config.php';
requireLogin();
require_once '../../includes/layout.php';

$base = BASE_URL;
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old = $_POST['old_password'] ?? '';
    $new = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    $db = getDB();
    $id = (int)$_SESSION['cashier_id'];
    $res = mysqli_query($db, "SELECT password FROM kasir WHERE id=$id");
    $row = mysqli_fetch_assoc($res);

    if (!password_verify($old, $row['password'])) {
        $error = 'Password lama tidak sesuai.';
    } elseif (strlen($new) < 6) {
        $error = 'Password baru minimal 6 karakter.';
    } elseif ($new !== $confirm) {
        $error = 'Konfirmasi password tidak cocok.';
    } else {
        $hash = password_hash($new, PASSWORD_BCRYPT);
        mysqli_query($db, "UPDATE kasir SET password='$hash' WHERE id=$id");
        $success = 'Password berhasil diubah.';
    }
}

pageStart('Ganti Password', 'profile');
?>

<div class="mb-6">
    <div class="flex-between">
        <h2 style="font-family:var(--font-display);font-size:24px;font-weight:500">
            <span class="ornament"></span>Ganti Password
        </h2>
        <a href="<?= $base ?>/pages/auth/profile.php" class="btn btn-outline">← Kembali</a>
    </div>
</div>

<div style="max-width:480px">
    <div class="card">
        <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label class="form-label">Password Lama</label>
                <input type="password" name="old_password" class="form-control" required>
            </div>
            <div class="form-group">
                <label class="form-label">Password Baru</label>
                <input type="password" name="new_password" class="form-control" placeholder="Min. 6 karakter" required>
            </div>
            <div class="form-group">
                <label class="form-label">Konfirmasi Password Baru</label>
                <input type="password" name="confirm_password" class="form-control" required>
            </div>
            <div class="flex gap-2" style="margin-top:20px">
                <button type="submit" class="btn btn-primary">Simpan</button>
                <a href="<?= $base ?>/pages/auth/profile.php" class="btn btn-ghost">Batal</a>
            </div>
        </form>
    </div>
</div>

<?php pageEnd(); ?>
