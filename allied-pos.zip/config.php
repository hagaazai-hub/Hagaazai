<?php
// Allied Shopping POS - Config
define('STORE_NAME', 'Allied Shopping');
define('STORE_LOCATION', 'Purgatory');
define('REGISTER_SECRET', getenv('REGISTER_SECRET') ?: 'Allied Shopping');

// Database
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'allied_pos');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');

// Base URL
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'];
$scriptPath = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
$basePath = ($scriptPath !== '/') ? $scriptPath : '';
define('BASE_URL', $protocol . '://' . $host);
define('PATH_URL', $protocol . '://' . $host . $basePath);

// Session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// DB Connection (mysqli)
function getDB() {
    static $conn = null;
    if ($conn === null) {
        $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if (!$conn) {
            die(json_encode(['error' => 'DB Connection failed: ' . mysqli_connect_error()]));
        }
        mysqli_set_charset($conn, 'utf8mb4');
    }
    return $conn;
}

function isLoggedIn() {
    return isset($_SESSION['cashier_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: ' . BASE_URL . '/pages/auth/login.php');
        exit;
    }
}

function getCurrentCashier() {
    if (!isLoggedIn()) return null;
    $db = getDB();
    $id = (int)$_SESSION['cashier_id'];
    $res = mysqli_query($db, "SELECT id, username, email FROM kasir WHERE id = $id");
    return mysqli_fetch_assoc($res);
}

function sanitize($str) {
    return mysqli_real_escape_string(getDB(), trim($str));
}

function generateTRX() {
    $db = getDB();
    $res = mysqli_query($db, "SELECT COUNT(*) as cnt FROM transaksi");
    $row = mysqli_fetch_assoc($res);
    $num = str_pad($row['cnt'] + 1, 6, '0', STR_PAD_LEFT);
    return 'TRX-' . date('Ymd') . '-' . $num;
}
