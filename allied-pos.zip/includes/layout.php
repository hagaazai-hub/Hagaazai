<?php
function renderSidebar($active = '') {
    $cashier = getCurrentCashier();
    $initial = strtoupper(substr($cashier['username'], 0, 1));
    $base = BASE_URL;
    echo <<<HTML
<aside class="sidebar" id="sidebar">
    <div class="sidebar-logo">
        <div class="store-name">Allied Shopping</div>
        <div class="store-loc">Point of Sale</div>
    </div>
    <nav class="sidebar-nav">
        <div class="nav-section-label">Main</div>
        <a href="{$base}/index.php" class="nav-item {$GLOBALS['_nav_dashboard']}">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
            Dashboard
        </a>
        <a href="{$base}/pages/cashier/pos.php" class="nav-item {$GLOBALS['_nav_pos']}">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"/></svg>
            Kasir / POS
        </a>
        <a href="{$base}/pages/cashier/history.php" class="nav-item {$GLOBALS['_nav_history']}">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
            Riwayat Transaksi
        </a>

        <div class="nav-section-label" style="margin-top:8px;">Manajemen</div>
        <a href="{$base}/pages/admin/products.php" class="nav-item {$GLOBALS['_nav_products']}">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
            Produk
        </a>
        <a href="{$base}/pages/admin/categories.php" class="nav-item {$GLOBALS['_nav_categories']}">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A2 2 0 013 12V7a2 2 0 014-4z"/></svg>
            Kategori
        </a>
        <a href="{$base}/pages/admin/cashiers.php" class="nav-item {$GLOBALS['_nav_cashiers']}">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
            Daftar Kasir
        </a>

        <div class="nav-section-label" style="margin-top:8px;">Akun</div>
        <a href="{$base}/pages/auth/profile.php" class="nav-item {$GLOBALS['_nav_profile']}">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
            Profile
        </a>
        <a href="{$base}/pages/auth/logout.php" class="nav-item">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
            Logout
        </a>
    </nav>
    <div class="sidebar-footer">
        <div class="cashier-info">
            <div class="cashier-avatar">{$initial}</div>
            <div>
                <div class="cashier-name">{$cashier['username']}</div>
                <div class="cashier-role">Kasir</div>
            </div>
        </div>
    </div>
</aside>
<div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSidebar()"></div>
HTML;
}

function renderTopbar($title) {
    $base = BASE_URL;
    echo <<<HTML
<div class="topbar">
    <div class="flex-center gap-2">
        <button class="btn btn-ghost btn-sm mobile-menu-btn" onclick="openSidebar()">
            <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
        </button>
        <h1 class="topbar-title">{$title}</h1>
    </div>
    <div class="topbar-actions">
        <span class="text-muted mono" style="font-size:12px"><?php echo date('d M Y'); ?></span>
    </div>
</div>
HTML;
}

function pageStart($title, $active) {
    global $_nav_dashboard, $_nav_pos, $_nav_history, $_nav_products, $_nav_categories, $_nav_cashiers, $_nav_profile;
    $_nav_dashboard = $_nav_pos = $_nav_history = $_nav_products = $_nav_categories = $_nav_cashiers = $_nav_profile = '';
    ${'_nav_'.$active} = 'active';
    $base = BASE_URL;
    echo <<<HTML
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{$title} — Allied Shopping POS</title>
<link rel="stylesheet" href="{$base}/css/style.css">
</head>
<body>
<div class="layout">
HTML;
    renderSidebar($active);
    echo '<div class="main">';
    renderTopbar($title);
    echo '<div class="content">';
}

function pageEnd() {
    $base = BASE_URL;
    echo <<<HTML
</div></div></div>
<script src="{$base}/js/app.js"></script>
</body></html>
HTML;
}
