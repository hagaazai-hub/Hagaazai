-- Allied Shopping POS Database
CREATE DATABASE IF NOT EXISTS `allied_pos` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `allied_pos`;

CREATE TABLE IF NOT EXISTS `kategori` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nama` VARCHAR(100) NOT NULL,
    `alias` CHAR(3) NOT NULL UNIQUE,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `kasir` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(100) NOT NULL UNIQUE,
    `email` VARCHAR(150) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `produk` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(200) NOT NULL,
    `sku` VARCHAR(100) NOT NULL UNIQUE,
    `discount` DECIMAL(5,2) DEFAULT 0,
    `kategori_id` INT NOT NULL,
    `berat` INT NOT NULL COMMENT 'gram',
    `price` DECIMAL(15,2) NOT NULL,
    `stock` INT NOT NULL DEFAULT 0,
    `sold` INT NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`kategori_id`) REFERENCES `kategori`(`id`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `transaksi` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `kode` VARCHAR(50) NOT NULL UNIQUE,
    `kasir_id` INT NOT NULL,
    `grand_total` DECIMAL(15,2) NOT NULL,
    `bayar` DECIMAL(15,2) NOT NULL DEFAULT 0,
    `kembalian` DECIMAL(15,2) NOT NULL DEFAULT 0,
    `products` JSON NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`kasir_id`) REFERENCES `kasir`(`id`)
) ENGINE=InnoDB;

-- Seed categories
INSERT IGNORE INTO `kategori` (`nama`, `alias`) VALUES
('Minuman', 'MNM'),
('Makanan', 'MKN'),
('Snack', 'SNK'),
('Kebersihan', 'KBR'),
('Kesehatan', 'KSH');

-- Seed admin cashier (password: admin123)
INSERT IGNORE INTO `kasir` (`username`, `email`, `password`) VALUES
('admin', 'admin@alliedshopping.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- Seed products
INSERT IGNORE INTO `produk` (`name`, `sku`, `discount`, `kategori_id`, `berat`, `price`, `stock`, `sold`) VALUES
('Aqua Mineral Water', 'MNM-AQUA-600', 0, 1, 600, 5000, 100, 45),
('Indomie Goreng', 'MKN-INDO-85', 5, 2, 85, 3500, 200, 180),
('Chitato Original', 'SNK-CHIT-68', 0, 3, 68, 12000, 50, 30),
('Sabun Lifebuoy', 'KBR-LIFE-90', 10, 4, 90, 8500, 75, 20),
('Panadol Extra', 'KSH-PANA-10', 0, 5, 10, 15000, 40, 15);
