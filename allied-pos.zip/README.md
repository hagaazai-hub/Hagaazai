# Allied Shopping POS

Sistema Point of Sale untuk Allied Shopping, Purgatory.

## Tech Stack
- PHP 7.2 Native (no framework, mysqli)
- MySQL 5.7
- Apache2
- Vanilla JS
- CSS Custom (no framework)

## Default Login
- Username: `admin`
- Password: `admin123`

## Register Secret Default
```
Allied Shopping
```

## Setup dengan Docker

```bash
# Clone / extract project
# Jalankan docker compose
docker compose up -d

# Akses di:
# App: http://localhost:8080
# phpMyAdmin: http://localhost:8081
```

## Setup XAMPP

1. Copy folder `allied-pos` ke `htdocs/`
2. Buat database `allied_pos` via phpMyAdmin
3. Import `database.sql`
4. Edit `config.php` jika perlu (DB credentials)
5. Akses: `http://localhost/allied-pos/`

> **Note XAMPP:** BASE_URL otomatis detect path, jadi bisa jalan di subfolder maupun root.

## Struktur Folder
```
allied-pos/
├── config.php              # Config utama
├── index.php               # Dashboard
├── database.sql            # Schema + seed data
├── Dockerfile
├── docker-compose.yml
├── css/
│   └── style.css
├── js/
│   └── app.js
├── includes/
│   └── layout.php          # Sidebar, topbar, dll
└── pages/
    ├── auth/
    │   ├── login.php
    │   ├── register.php
    │   ├── logout.php
    │   ├── profile.php       # View profile
    │   ├── edit_profile.php  # Edit profile (terpisah)
    │   └── change_password.php
    ├── admin/
    │   ├── products.php
    │   ├── categories.php
    │   └── cashiers.php
    └── cashier/
        ├── pos.php           # Halaman kasir utama
        ├── history.php       # Riwayat transaksi
        └── receipt.php       # Print/download struk
```

## Fitur
- ✅ Auth (login, register dengan secret key, logout)
- ✅ Dashboard dengan statistik
- ✅ Manajemen Produk (CRUD, SKU otomatis: ALIAS-NAMA-BERAT)
- ✅ Manajemen Kategori (CRUD, alias 3 char)
- ✅ Kasir POS (input via SKU scan/ketik, grid produk, filter kategori)
- ✅ Keranjang belanja dengan qty control
- ✅ Kalkulasi diskon otomatis
- ✅ Riwayat transaksi dengan filter
- ✅ Print/download struk PDF
- ✅ Profil kasir (view & edit terpisah)
- ✅ Daftar kasir dengan reset password
- ✅ Responsive (mobile-friendly)

## SKU Format
`KATEGORI_ALIAS-NAMA_PRODUK_3CHAR-BERAT_GRAM`

Contoh: `MNM-AQUA-600` (Minuman - Aqua - 600 gram)
