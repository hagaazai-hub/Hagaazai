<?php
require_once 'config.php';
requireLogin();
require_once 'includes/layout.php';

$db = getDB();
$base = BASE_URL;

// Stats
$r = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as c, COALESCE(SUM(grand_total),0) as t FROM transaksi WHERE DATE(created_at)=CURDATE()"));
$todayCount = $r['c'];
$todayTotal = $r['t'];

$r2 = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as c, COALESCE(SUM(grand_total),0) as t FROM transaksi WHERE MONTH(created_at)=MONTH(CURDATE()) AND YEAR(created_at)=YEAR(CURDATE())"));
$monthCount = $r2['c'];
$monthTotal = $r2['t'];

$totalProduk = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as c FROM produk"))['c'];
$totalKasir = mysqli_fetch_assoc(mysqli_query($db, "SELECT COUNT(*) as c FROM kasir"))['c'];

// Recent transactions
$recent = mysqli_query($db, "SELECT t.*, k.username FROM transaksi t JOIN kasir k ON t.kasir_id=k.id ORDER BY t.created_at DESC LIMIT 8");

// Low stock
$lowStock = mysqli_query($db, "SELECT * FROM produk WHERE stock <= 10 ORDER BY stock ASC LIMIT 5");

pageStart('Dashboard', 'dashboard');
?>

<div class="stats-grid mb-6">
    <div class="stat-card">
        <div class="stat-label">Transaksi Hari Ini</div>
        <div class="stat-value"><?= $todayCount ?></div>
        <div class="stat-sub">Total <?= 'Rp ' . number_format($todayTotal, 0, ',', '.') ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Pendapatan Bulan Ini</div>
        <div class="stat-value" style="font-size:22px">Rp <?= number_format($monthTotal, 0, ',', '.') ?></div>
        <div class="stat-sub"><?= $monthCount ?> transaksi</div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Total Produk</div>
        <div class="stat-value"><?= $totalProduk ?></div>
        <div class="stat-sub">produk terdaftar</div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Kasir Aktif</div>
        <div class="stat-value"><?= $totalKasir ?></div>
        <div class="stat-sub">akun kasir</div>
    </div>
</div>

<div class="flex-responsive" style="gap:20px;align-items:start">
    <!-- Recent Transactions -->
    <div class="card half-on-desktop">
        <div class="card-header">
            <span class="card-title">Transaksi Terbaru</span>
            <a href="<?= $base ?>/pages/cashier/history.php" class="btn btn-ghost btn-sm">Lihat Semua</a>
        </div>
        <div class="table-wrap">
            <table class="table">
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Kasir</th>
                        <th>Total</th>
                        <th>Waktu</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($recent) === 0): ?>
                        <tr>
                            <td colspan="4" style="text-align:center;color:var(--text3);padding:24px">Belum ada transaksi</td>
                        </tr>
                    <?php else: ?>
                        <?php while ($row = mysqli_fetch_assoc($recent)): ?>
                            <tr>
                                <td><span class="mono"><?= $row['kode'] ?></span></td>
                                <td><?= htmlspecialchars($row['username']) ?></td>
                                <td style="color:var(--gold);font-family:var(--font-mono)">Rp <?= number_format($row['grand_total'], 0, ',', '.') ?></td>
                                <td style="color:var(--text3);font-size:12px"><?= date('d/m H:i', strtotime($row['created_at'])) ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Low Stock -->
    <div class="card half-on-desktop">
        <div class="card-header">
            <span class="card-title">Stok Menipis</span>
            <a href="<?= $base ?>/pages/admin/products.php" class="btn btn-ghost btn-sm">Kelola</a>
        </div>
        <?php if (mysqli_num_rows($lowStock) === 0): ?>
            <div style="text-align:center;padding:24px;color:var(--text3)">Semua stok aman ✓</div>
        <?php else: ?>
            <div class="table-wrap">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Produk</th>
                            <th>SKU</th>
                            <th>Stok</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        mysqli_data_seek($lowStock, 0);
                        while ($p = mysqli_fetch_assoc($lowStock)): ?>
                            <tr>
                                <td><?= htmlspecialchars($p['name']) ?></td>
                                <td class="mono"><?= $p['sku'] ?></td>
                                <td>
                                    <span class="badge <?= $p['stock'] == 0 ? 'badge-red' : 'badge-gold' ?>">
                                        <?= $p['stock'] ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php pageEnd(); ?>